package com.dynamicpill.module;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Simple black capsule. */
public class PillView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float borderPx = 0f;

    public PillView(Context context) {
        super(context);
        paint.setColor(0xFF000000); // pure dark black, full alpha
        paint.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFFFFFFFF); // safed border
        stroke.setStyle(Paint.Style.STROKE);
    }

    /** Border thickness in pixels; 0 = no border. */
    public void setBorder(float px) {
        if (px != borderPx) {
            borderPx = Math.max(0f, px);
            invalidate();
        }
    }

    /** 0..100 percent; 100 = fully solid black. */
    public void setPillAlpha(int percent) {
        paint.setAlpha(Math.round(255f * Math.max(0, Math.min(100, percent)) / 100f));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        rect.set(0, 0, getWidth(), getHeight());
        float r = getHeight() / 2f;
        canvas.drawRoundRect(rect, r, r, paint);
        if (borderPx > 0f) {
            stroke.setStrokeWidth(borderPx);
            float in = borderPx / 2f;
            rect.set(in, in, getWidth() - in, getHeight() - in);
            float rr = Math.max(0f, getHeight() / 2f - in);
            canvas.drawRoundRect(rect, rr, rr, stroke);
        }
    }
}
