package com.dynamicpill.module;

public class LineTileService extends BaseTile {
    @Override protected String prefKey() { return PillController.K_LINE_ON; }
    @Override protected int iconRes() { return R.drawable.ic_line; }
    @Override protected String tileName() { return "Pill Line"; }
}
